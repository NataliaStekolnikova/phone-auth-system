from django.urls import path
from . import views

urlpatterns = [
    path('send-code/', views.send_verification_code, name='send_verification_code'),
    path('verify-code/', views.verify_code, name='verify_code'),
    path('profile/', views.get_profile, name='get_profile'),
    path('activate-invite/', views.activate_invite_code, name='activate_invite_code'),
]