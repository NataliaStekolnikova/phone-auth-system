# Phone Auth System - Реферальная система

Простая реферальная система с авторизацией по номеру телефона, построенная на Django и Django REST Framework.

## 🚀 Функционал

- **Авторизация по SMS**: Двухэтапная авторизация с отправкой 4-значного кода
- **Автоматическая регистрация**: Создание пользователя при первой авторизации
- **Уникальные инвайт-коды**: Автоматическая генерация 6-значных кодов для каждого пользователя
- **Реферальная система**: Активация чужих инвайт-кодов и отслеживание рефералов
- **REST API**: Полноценное API для всех операций

## 🛠 Технологии

- **Python 3.12**
- **Django 4.2.7**
- **Django REST Framework 3.14.0**
- **SQLite** (база данных)
- **Token Authentication**

## 📋 Требования

- Python 3.8+
- pip
- virtualenv (рекомендуется)

## ⚡ Быстрый старт

### 1. Клонирование и настройка

```bash
# Клонируйте репозиторий
git clone <repository-url>
cd phone_auth_system

# Создайте виртуальное окружение
python -m venv venv

# Активируйте окружение
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# Установите зависимости
pip install -r requirements.txt
```

### 2. Настройка базы данных

```bash
# Создайте миграции
python manage.py makemigrations

# Примените миграции
python manage.py migrate
```

### 3. Запуск сервера

```bash
python manage.py runserver
```

Сервер будет доступен по адресу: `http://127.0.0.1:8000/`

## 📚 API Документация

### Base URL
```
http://127.0.0.1:8000/api/users/
```

### Endpoints

#### 1. Отправка SMS-кода
**POST** `/send-code/`

Отправляет 4-значный код верификации на указанный номер телефона.

**Request:**
```json
{
    "phone_number": "+375294567892"
}
```

**Response:**
```json
{
    "message": "Код отправлен на номер",
    "phone_number": "+375294567892",
    "verification_code": "1234"
}
```

#### 2. Верификация кода
**POST** `/verify-code/`

Проверяет SMS-код и авторизует/регистрирует пользователя.

**Request:**
```json
{
    "phone_number": "+375294567892",
    "verification_code": "1234"
}
```

**Response:**
```json
{
    "message": "Успешная авторизация",
    "token": "abc123def456...",
    "user_id": 1,
    "phone_number": "+375294567892",
    "invite_code": "ABC123",
    "is_new_user": true
}
```

#### 3. Профиль пользователя
**GET** `/profile/`

Получает информацию о текущем пользователе и его рефералах.

**Headers:**
```
Authorization: Token YOUR_TOKEN_HERE
```

**Response:**
```json
{
    "user_id": 1,
    "phone_number": "+375294567892",
    "invite_code": "ABC123",
    "activated_invite_code": null,
    "referrals": [
        {
            "phone_number": "+375291234567",
            "joined_date": "2025-07-24T17:43:17.442191Z"
        }
    ],
    "referrals_count": 1
}
```

#### 4. Активация инвайт-кода
**POST** `/activate-invite/`

Активирует инвайт-код другого пользователя.

**Headers:**
```
Authorization: Token YOUR_TOKEN_HERE
```

**Request:**
```json
{
    "invite_code": "ABC123"
}
```

**Response:**
```json
{
    "message": "Инвайт-код успешно активирован",
    "activated_invite_code": "ABC123",
    "inviter_phone": "+375294567892"
}
```

## 🧪 Тестирование

### Postman коллекция
В корне проекта находится файл `Phone Auth System.postman_collection.json` с готовыми запросами для тестирования API.

**Импорт в Postman:**
1. Откройте Postman
2. File → Import
3. Выберите файл `Phone Auth System.postman_collection.json`
4. Запустите запросы в последовательности: Send Code → Verify Code → Get Profile → Activate Invite

### Ручное тестирование через curl

```bash
# 1. Получить SMS-код
curl -X POST http://127.0.0.1:8000/api/users/send-code/ \
  -H "Content-Type: application/json" \
  -d '{"phone_number": "+375294567892"}'

# 2. Верифицировать код (замените на полученный код)
curl -X POST http://127.0.0.1:8000/api/users/verify-code/ \
  -H "Content-Type: application/json" \
  -d '{"phone_number": "+375294567892", "verification_code": "1234"}'

# 3. Получить профиль (замените токен)
curl -X GET http://127.0.0.1:8000/api/users/profile/ \
  -H "Authorization: Token YOUR_TOKEN"

# 4. Активировать инвайт-код (замените токен и код)
curl -X POST http://127.0.0.1:8000/api/users/activate-invite/ \
  -H "Authorization: Token YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"invite_code": "ABC123"}'
```

## 🏗 Структура проекта

```
phone_auth_system/
├── auth_project/           # Основные настройки Django
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── users/                  # Приложение пользователей
│   ├── models.py          # Модели User и PhoneVerification
│   ├── views.py           # API views
│   ├── urls.py            # URL маршруты
│   └── migrations/        # Миграции базы данных
├── venv/                   # Виртуальное окружение
├── manage.py              # Django management
├── requirements.txt       # Зависимости
└── README.md             # Документация
```

## 🔒 Безопасность

- **Token Authentication**: Все защищенные endpoints требуют токен авторизации
- **Уникальные инвайт-коды**: Автоматическая генерация уникальных кодов
- **Ограничения**: Один инвайт-код на пользователя
- **Валидация**: Проверка существования инвайт-кодов

## 🚧 Известные ограничения

- SMS-коды отправляются в ответе API (только для тестирования)
- Используется SQLite (для production рекомендуется PostgreSQL)
- Коды верификации не имеют времени жизни
- Отсутствует rate limiting

## 🔮 Возможные улучшения

- [ ] Интеграция с реальным SMS-провайдером
- [ ] Переход на PostgreSQL
- [ ] Добавление времени жизни для SMS-кодов
- [ ] Добавление rate limiting
- [ ] Django Templates интерфейс
- [ ] ReDoc документация
- [ ] Docker контейнеризация
- [ ] Система уведомлений
- [ ] Аналитика рефералов

## 👨‍💻 Автор

Создано как тестовое задание для Python разработчика.

## 📄 Лицензия

MIT LicenseDjango==4.2.7
djangorestframework==3.14.0
python-decouple==3.8