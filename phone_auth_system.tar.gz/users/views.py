from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate
from django.db import IntegrityError
import random
import time
from .models import User, PhoneVerification


@api_view(['POST'])
@permission_classes([AllowAny])
def send_verification_code(request):
    phone_number = request.data.get('phone_number')
    
    if not phone_number:
        return Response({
            'error': 'Номер телефона обязателен'
        }, status=status.HTTP_400_BAD_REQUEST)
    verification_code = str(random.randint(1000, 9999))
    time.sleep(random.uniform(1, 2))
    PhoneVerification.objects.create(
        phone_number=phone_number,
        verification_code=verification_code
    )
    
    return Response({
        'message': 'Код отправлен на номер',
        'phone_number': phone_number,
        'verification_code': verification_code  
    }, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes([AllowAny])
def verify_code(request):
    phone_number = request.data.get('phone_number')
    verification_code = request.data.get('verification_code')
    
    if not phone_number or not verification_code:
        return Response({
            'error': 'Номер телефона и код обязательны'
        }, status=status.HTTP_400_BAD_REQUEST)
    try:
        phone_verification = PhoneVerification.objects.filter(
            phone_number=phone_number,
            verification_code=verification_code,
            is_verified=False
        ).latest('created_at')
    except PhoneVerification.DoesNotExist:
        return Response({
            'error': 'Неверный код'
        }, status=status.HTTP_400_BAD_REQUEST)
    phone_verification.is_verified = True
    phone_verification.save()
    user, created = User.objects.get_or_create(
        phone_number=phone_number 
    )
    token, _ = Token.objects.get_or_create(user=user)
    
    return Response({
        'message': 'Успешная авторизация',
        'token': token.key,
        'user_id': user.id,
        'phone_number': user.phone_number,
        'invite_code': user.invite_code,
        'is_new_user': created
    }, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_profile(request):
    user = request.user
    referrals = user.get_referrals()
    
    return Response({
        'user_id': user.id,
        'phone_number': user.phone_number,
        'invite_code': user.invite_code,
        'activated_invite_code': user.activated_invite_code,
        'referrals': [
            {
                'phone_number': ref.phone_number,
                'joined_date': ref.created_at
            } for ref in referrals
        ],
        'referrals_count': referrals.count()
    }, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def activate_invite_code(request):
    invite_code = request.data.get('invite_code')
    user = request.user
    
    if not invite_code:
        return Response({
            'error': 'Инвайт-код обязателен'
        }, status=status.HTTP_400_BAD_REQUEST)
    if user.activated_invite_code:
        return Response({
            'error': f'Вы уже активировали инвайт-код: {user.activated_invite_code}'
        }, status=status.HTTP_400_BAD_REQUEST)
    if invite_code == user.invite_code:
        return Response({
            'error': 'Нельзя активировать собственный инвайт-код'
        }, status=status.HTTP_400_BAD_REQUEST)
    try:
        inviter = User.objects.get(invite_code=invite_code)
    except User.DoesNotExist:
        return Response({
            'error': 'Инвайт-код не существует'
        }, status=status.HTTP_400_BAD_REQUEST)
    user.activated_invite_code = invite_code
    user.save()
    
    return Response({
        'message': 'Инвайт-код успешно активирован',
        'activated_invite_code': invite_code,
        'inviter_phone': inviter.phone_number
    }, status=status.HTTP_200_OK)